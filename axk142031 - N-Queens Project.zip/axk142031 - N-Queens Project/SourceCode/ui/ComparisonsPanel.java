package ai.star.ui;

import ai.star.enums.Panels;

public class ComparisonsPanel extends MyResultsPanel {
	
	public ComparisonsPanel(Panels panelType) {
		super(panelType);
	}

}
